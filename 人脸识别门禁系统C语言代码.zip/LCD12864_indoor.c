#include <STC8A.h>
#include <intrins.h>


sbit LCD_RS2=P2^5;
sbit LCD_RW2=P2^4;
sbit LCD_E2=P2^3;
sbit LCD_RST2=P4^1;

typedef unsigned char u8;
typedef unsigned int u16;


void write2(u8 a)
{
	P22=(bit)(a&0x01);
  P21=(bit)(a&0x02);
	P42=(bit)(a&0x04);
	P20=(bit)(a&0x08);
	P73=(bit)(a&0x10);
	P72=(bit)(a&0x20);
	P71=(bit)(a&0x40);
	P70=(bit)(a&0x80);
	
}



u8 read2()
{
  u8 b=0;
	bit c,d,e,f,g,h,i,j;
	c=P22;
  d=P21;
	e=P42;
	f=P20;
	g=P73;
	h=P72;
	i=P71;
	j=P70;
	b=(b|j)<<1;
	b=(b|i)<<1;
	b=(b|h)<<1;
	b=(b|g)<<1;
	b=(b|f)<<1;
	b=(b|e)<<1;
	b=(b|d)<<1;
	b=(b|c)<<1;
	
	return b;

}

void Delay200us2()		//@24.000MHz
{
	unsigned char i, j;

	i = 7;
	j = 57;
	do
	{
		while (--j);
	} while (--i);
}

void Delay30ms2()		//@24.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 4;
	j = 168;
	k = 10;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


void Busy2()
{
	u8 sta;
	write2(0xFF);
LCD_E2=0;
	LCD_RW2=1;
	LCD_RS2=0;
	do
	{
	LCD_E2=1;
	sta=read2();
		LCD_E2=0;
	}
	while(sta&0x80);

}
void Lcd_WriteCmd2(u8 com)
{
	Busy2();
LCD_E2=0;
	LCD_RW2=0;
	LCD_RS2=0;
	_nop_();
	_nop_();
	write2(com);
	_nop_();
	_nop_();
  LCD_E2=1;
	Delay200us2();
LCD_E2=0;
}
	
void Lcd_WriteData2(u8 dat)
{
	Busy2();
LCD_E2=0;
	LCD_RW2=0;
	LCD_RS2=1;
	_nop_();
	_nop_();
	write2(dat);
	_nop_();
	_nop_();	
	LCD_E2=1;
	Delay200us2();
	LCD_E2=0;
}

void LCD_Init2()
{
LCD_RST2=0;
Delay30ms2();
LCD_RST2=1;
Delay30ms2();	
 Lcd_WriteCmd2(0X30);
 Lcd_WriteCmd2(0X08);
	 Lcd_WriteCmd2(0X01);
	 Lcd_WriteCmd2(0X06);
	 Lcd_WriteCmd2(0X0C);
}

void LCD12864_Clear_Screen2(u8 value)
        {
            u8 i,j;

            Lcd_WriteCmd2(0x34);
            Lcd_WriteCmd2(0x36);


            for(i=0;i<64;i++){
                    if(i<32){
                    Lcd_WriteCmd2(0x80+i);
                    Lcd_WriteCmd2(0x80);
                    }else {
                    Lcd_WriteCmd2(0x80+(i-32));
                    Lcd_WriteCmd2(0x88);
                    }

                    for(j=0;j<16;j++)
                        Lcd_WriteData2(value);
            }
        }

unsigned char addresses2[] = {0x80,0x90,0x88,0x98};

void LCD_Display_Char2(u8 x,u8 y,u8 dat)
{
 Lcd_WriteCmd2(0X30);
 Lcd_WriteCmd2(0X06);
	 Lcd_WriteCmd2(addresses2[x-1]+(y-1));
Lcd_WriteData2(dat);

}
void LCD_Display_Chars2(u8 x,u8 y,u8 *dat)
{
 Lcd_WriteCmd2(0X30);
 Lcd_WriteCmd2(0X06);
	 Lcd_WriteCmd2(addresses2[x-1]+(y-1));
	while(*dat!='\0')
	{
Lcd_WriteData2(*dat++);
	}
}