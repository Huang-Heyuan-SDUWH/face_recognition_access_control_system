#include <STC8A.h>
#include <intrins.h>
//����ı����ͺ��������1 ���ڵ�LCD�����ͺ��������2

sbit LCD_RS=P7^5;
sbit LCD_RW=P7^6;
sbit LCD_E=P7^7;
sbit LCD_RST=P6^3;

typedef unsigned char u8;
typedef unsigned int u16;


void write1(u8 a)
{
	P52=(bit)(a&0x01);
  P53=(bit)(a&0x02);
	P11=(bit)(a&0x04);
	P12=(bit)(a&0x08);
	P13=(bit)(a&0x10);
	P60=(bit)(a&0x20);
	P61=(bit)(a&0x40);
	P62=(bit)(a&0x80);
	
}



u8 read1()
{
  u8 b=0;
	bit c,d,e,f,g,h,i,j;
	c=P52;
  d=P53;
	e=P11;
	f=P12;
	g=P13;
	h=P60;
	i=P61;
	j=P62;
	b=(b|j)<<1;
	b=(b|i)<<1;
	b=(b|h)<<1;
	b=(b|g)<<1;
	b=(b|f)<<1;
	b=(b|e)<<1;
	b=(b|d)<<1;
	b=(b|c)<<1;
	
	return b;

}

void Delay200us1()		//@24.000MHz
{
	unsigned char i, j;

	i = 7;
	j = 57;
	do
	{
		while (--j);
	} while (--i);
}

void Delay30ms1()		//@24.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 4;
	j = 168;
	k = 10;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


void Busy1()
{
	u8 sta;
	write1(0xFF);
LCD_E=0;
	LCD_RW=1;
	LCD_RS=0;
	do
	{
	LCD_E=1;
	sta=read1();
		LCD_E=0;
	}
	while(sta&0x80);

}
void Lcd_WriteCmd1(u8 com)
{
	Busy1();
LCD_E=0;
	LCD_RW=0;
	LCD_RS=0;
	_nop_();
	_nop_();
	write1(com);
	_nop_();
	_nop_();
  LCD_E=1;
	Delay200us1();
LCD_E=0;
}
	
void Lcd_WriteData1(u8 dat)
{
	Busy1();
LCD_E=0;
	LCD_RW=0;
	LCD_RS=1;
	_nop_();
	_nop_();
	write1(dat);
	_nop_();
	_nop_();	
	LCD_E=1;
	Delay200us1();
	LCD_E=0;
}

void LCD_Init1()
{
LCD_RST=0;
Delay30ms1();
LCD_RST=1;
Delay30ms1();	
 Lcd_WriteCmd1(0X30);
 Lcd_WriteCmd1(0X08);
	 Lcd_WriteCmd1(0X01);
	 Lcd_WriteCmd1(0X06);
	 Lcd_WriteCmd1(0X0C);
}

void LCD12864_Clear_Screen1(u8 value)
        {
            u8 i,j;

            Lcd_WriteCmd1(0x34);
            Lcd_WriteCmd1(0x36);


            for(i=0;i<64;i++){
                    if(i<32){
                    Lcd_WriteCmd1(0x80+i);
                    Lcd_WriteCmd1(0x80);
                    }else {
                    Lcd_WriteCmd1(0x80+(i-32));
                    Lcd_WriteCmd1(0x88);
                    }

                    for(j=0;j<16;j++)
                        Lcd_WriteData1(value);
            }
        }

unsigned char addresses1[] = {0x80,0x90,0x88,0x98};

void LCD_Display_Char1(u8 x,u8 y,u8 dat)
{
 Lcd_WriteCmd1(0X30);
 Lcd_WriteCmd1(0X06);
	 Lcd_WriteCmd1(addresses1[x-1]+(y-1));
Lcd_WriteData1(dat);

}
void LCD_Display_Chars1(u8 x,u8 y,u8 *dat)
{
 Lcd_WriteCmd1(0X30);
 Lcd_WriteCmd1(0X06);
	 Lcd_WriteCmd1(addresses1[x-1]+(y-1));
	while(*dat!='\0')
	{
Lcd_WriteData1(*dat++);
	}
}