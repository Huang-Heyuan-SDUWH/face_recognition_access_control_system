#include<STC8A.h>

sbit Buzz=P4^3;

unsigned int bz;


void openbuzz()
{
	Buzz=0;
	for(bz=0;bz<2000;bz++);
  Buzz=1;
	for(bz=0;bz<2000;bz++);
}
