#include <STC8A.h>
#include <intrins.h>

#define BUFFER_SIZE		16
typedef unsigned char u8;
typedef unsigned int u16;

unsigned char rxbuf[16],rxempty, rxcnt,rxflag,waitflag;
unsigned short int length_val;
unsigned int timeout;




extern UartInit();
extern UartSend(char dat);
extern bit busy0;
extern LCD_Init2();
extern LCD_Display_Chars2(u8 x,u8 y,u8 *dat);



void Delay10ms()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 72;
	j = 205;
	do
	{
		while (--j);
	} while (--i);
}
void Delay1000ms()		//@5.5296MHz
{
	unsigned char i, j, k;

	i = 29;
	j = 14;
	k = 54;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}





void serial_IT(void) interrupt 4 
{
    if (RI) 
    {                                       
        RI = 0;                             
			
				if(rxflag==0)
				{
					rxbuf[rxcnt++] = SBUF;
					if(rxcnt>2)
					{
						if(waitflag==1)
						{
							if((rxbuf[rxcnt-2]=='o')&&(rxbuf[rxcnt-1]=='k'))//���ڽ��վ������ݸ�ʽASCII��0mm~2000mm
							{
								waitflag=2;
							}
						}
						else
						{
							if((rxbuf[rxcnt-1]=='m')&&(rxbuf[rxcnt-2]=='m'))//���ڽ��վ������ݸ�ʽASCII��0mm~2000mm
							{
								rxflag=1;
							}
						}
					}
					else if(rxcnt>=16)
					{
						rxcnt=0;
					}
				}
				else
				{
					rxempty = SBUF;
				}
				
    }
    if(TI)
    {
        TI = 0; 
busy0 = 0;			
    }
}
void laserinit()
{
	
//   u8 distance[]="0000";

//	LCD_Init2();
	UartInit();
	ES = 1;
  EA = 1;
	UartSend('s');
	UartSend('5');
	UartSend('-');
	UartSend('1');
	UartSend('#'); //��Ϊ������ȡģʽ
	Delay10ms();
	waitflag=1;
	while(waitflag==1);
	waitflag=0; 
	Delay1000ms();
	rxcnt=0;}
//	while(1)
//	{

void distance()
{ unsigned char i;
		Delay1000ms();
		UartSend('r');
		UartSend('6');
		UartSend('#');//������ȡ��������
		timeout=10000;
//		distance[0]='0';
//		distance[1]='0';
//		distance[2]='0';
//		distance[3]='0';
		while((rxflag==0)&&(timeout--));
		
		if(rxflag)//���յ�1����Ч����
		{
			for(i=0; i<rxcnt; i++)
			{
				if(rxbuf[i]=='m')
				{
					if(rxbuf[i+1]=='m')	//ASCII��ת��Ϊ16�������ݣ���λmm
					{
						if((i>0)&&(rxbuf[i-1]>='0')&&(rxbuf[i-1]<='9'))
						{
							length_val=rxbuf[i-1]-'0';
						  //distance[3]=rxbuf[i-1];
							}
						if((i>1)&&(rxbuf[i-2]>='0')&&(rxbuf[i-2]<='9')){
							length_val+=(rxbuf[i-2]-'0')*10;
						//distance[2]=rxbuf[i-2];
						}
						if((i>2)&&(rxbuf[i-3]>='0')&&(rxbuf[i-3]<='9')){
							length_val+=(rxbuf[i-3]-'0')*100;
						//distance[1]=rxbuf[i-3];
						}
						if((i>3)&&(rxbuf[i-4]>='0')&&(rxbuf[i-4]<='9')){
							length_val+=(rxbuf[i-4]-'0')*1000;
					//	distance[0]=rxbuf[i-4];
						}
//						distance[0]=length_val/1000+'0';//ǧλ
//	distance[1]=length_val%1000/100+'0';//��λ
//	distance[2]=length_val%100/10+'0';//ʮλ
//	distance[3]=length_val%10+'0';//��λ
						break;
					}
				}
			}
//			LCD_Display_Chars2(1,1,rxbuf);
//			LCD_Display_Chars2(2,1,"����");
//			LCD_Display_Chars2(3,1,distance);
			rxflag = 0;
			rxcnt = 0;
		}
	}	
