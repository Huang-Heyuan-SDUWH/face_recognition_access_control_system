#include <STC8A.h>
#include <intrins.h>
typedef unsigned char u8;
typedef unsigned int u16;
u8 count_pass;
u16 i;
u16 ii;

bit pass=0;//�ж�����ͨ����
char close=1;//�ж����޹���
char closecount=0;

extern motorne90();
extern motorne45();
extern Uart3Init();
extern LCD_Init2();
extern LCD_Display_Chars2(u8 x,u8 y,u8 *dat);
extern LCD_Display_Chars1(u8 x,u8 y,u8 *dat);
extern LCD_Display_Char1(u8 x,u8 y,u8 dat);
extern LCD_Display_Char2(u8 x,u8 y,u8 dat);
extern LCD12864_Clear_Screen1(u8 value);
extern LCD12864_Clear_Screen2(u8 value);
extern LCD_Init1();
extern openbuzz();

extern Uart3detect1();
extern Uart3detect2();
extern char count;//��������ͨ������
extern char motor;//�ж��Ƿ���Ҫ�����������
extern bit startkey;//�ж��Ƿ���������
extern bit closekey;//�Ƿ�رհ���
extern bit startkey2;
extern bit closekey2;

//extern T1();

extern T0();
extern length_val;
extern distance();
extern laserinit();
extern key1();
extern keystart();
extern key2();
extern keystart2();

extern Delay100ms();






void main()
{
  Uart3Init();
  IE2 = 0x08;
  EA = 1;
  LCD_Init1();
  LCD_Init2();
 // T0();
	LCD_Display_Chars2(3,1,"����");//���ϵͳ�Ƿ���������������
	
	while(1)
	{		

		for(i=0;i<1000;i++)
		{P64=0;
Uart3detect1();
}
		LCD_Display_Chars1(2,1,"��ͨ��");
    LCD_Display_Char1(2,4,(count+'0'));
		for(i=0;i<100;i++)
{
key1();
	key2();
}
		if(startkey==1)
	{
	startkey=0;
		for(i=0;i<1000;i++)
		{
		key1();
			keystart();
			if(closekey==1)
			{
				break;
			}
		}
	}
		if(startkey2==1)
	{
	startkey2=0;
		for(i=0;i<1000;i++)
		{
		key2();
			keystart2();
			if(closekey2==1)
			{
				break;
			}
		}
	}
	
			if(motor==1)
		{
			
			for(i=0;i<100;i++)
			{
		motorne90();
		  }
			//motor=0;
			close=0;
			
			for(i=0;i<65530;i++)
			
			{
				for(ii=0;ii<30;ii++)
				{
				if(P10==0)
				{
			  while(P10==0);
		  	  count-=1;
		  		
					LCD_Display_Char1(2,4,(count+'0'));
		  	}
	   	}}
			
			for(i=0;i<40;i++){
			openbuzz();}
			LCD_Display_Char1(2,4,(count+'0'));
			if(count<0)
			{
				for(i=0;i<1000;i++){
			openbuzz();}
			
    

				LCD_Display_Chars1(1,1,"����ͨ��");

				LCD_Display_Chars2(1,1,"����ͨ��");
			
			}
			laserinit();
			for(i=0;i<100;i++){
				distance();
			if(length_val>1400)//���ż��
			{distance();
				if(length_val>1400)
				{
				
				close=1;
				for(i=0;i<100;i++)
			  {
		      motorne45();
					
		    }
				break;
			}
			}}
			if(close==0)
			{
				LCD_Display_Chars2(2,1,"û������");
			for(i=0;i<1000;i++){
			openbuzz();
			}
	
		}

		LCD_Display_Chars2(1,1,"            ");
		LCD_Display_Chars2(2,1,"            ");
		LCD_Display_Chars2(3,1,"            ");
		LCD_Display_Chars2(4,1,"            ");
		LCD_Display_Chars1(1,1,"            ");		
		LCD_Display_Chars1(2,1,"            ");
		LCD_Display_Chars1(3,1,"            ");
		LCD_Display_Chars1(4,1,"            ");
		
		

		LCD_Display_Chars2(2,1,"��û�й�");
			for(i=0;i<1000;i++){
			openbuzz();
			}
			laserinit();
			for(i=0;i<100;i++){
				distance();
			if(length_val>1400)//���ż��
			{distance();
				if(length_val>1400)
				{
				
				close=1;
				for(i=0;i<100;i++)
			  {
		      motorne45();
					
		    }
				break;
			}
			}}
		
		
		
		IAP_CONTR|=0x20;//������λ
		}


		count=0;
		motor=0;


	}
	
	
	
}





