#include <reg52.h>
#include <intrins.h>
sbit PWM=P0^4;

//-90��0.5ms&19.5ms        -45�� 1ms & 19ms    0��  1.5ms  &  18.5ms    45��   2ms  &  18ms   90��  2.5ms  &  17.5ms
void 	motorne90();
void 	motorne45();
void 	motor0();
void 	motorpo45();
void 	motorpo90();

//void main()
//{
//unsigned long i;
//	while(1)
//	{
//	PWM=0;
//		for(i=0;i<100;i++)
//		{
//		motorne90();
//		
//		}
//		for(i=0;i<100;i++)
//		{
//		motorne45();
//		 
//		}
//		
//	
//	}



//}

void Delay500us()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 4;
	j = 148;
	do
	{
		while (--j);
	} while (--i);
}

void Delay19500us()		//@5.5296MHz
{
	unsigned char i, j;

	i = 141;
	j = 6;
	do
	{
		while (--j);
	} while (--i);
}


void Delay1ms()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 8;
	j = 43;
	do
	{
		while (--j);
	} while (--i);
}



void Delay19ms()		//@5.5296MHz
{
	unsigned char i, j;

	i = 137;
	j = 111;
	do
	{
		while (--j);
	} while (--i);
}



void Delay2ms()		//@5.5296MHz
{
	unsigned char i, j;

	i = 15;
	j = 90;
	do
	{
		while (--j);
	} while (--i);
}


void Delay18ms()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 130;
	j = 64;
	do
	{
		while (--j);
	} while (--i);
}


void Delay1500us()		//@5.5296MHz
{
	unsigned char i, j;

	i = 11;
	j = 195;
	do
	{
		while (--j);
	} while (--i);
}


void Delay18500us()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	i = 133;
	j = 216;
	do
	{
		while (--j);
	} while (--i);
}


void Delay2500us()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 18;
	j = 241;
	do
	{
		while (--j);
	} while (--i);
}




void Delay17500us()		//@5.5296MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 126;
	j = 169;
	do
	{
		while (--j);
	} while (--i);
}





void motorne45()
{
PWM=1;
	Delay1ms();
	PWM=0;
	Delay19ms();

}

void motorpo45()
{
PWM=1;
	Delay2ms();
	PWM=0;
	Delay18ms();
}

void motor0()
{
PWM=1;
	Delay1500us();
	PWM=0;
	Delay18500us();
}
void motorpo90()
{
PWM=1;
	Delay2500us();
	PWM=0;
	Delay17500us();
}
void motorne90()
{
PWM=1;
	Delay500us();
	PWM=0;
	Delay19500us();
}