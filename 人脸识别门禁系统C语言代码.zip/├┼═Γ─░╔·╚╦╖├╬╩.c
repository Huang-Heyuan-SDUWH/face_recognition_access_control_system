#include <STC8A.h>
#include <intrins.h>
sbit KEY1=P6^4;
sbit KEY2=P6^5;
sbit KEY3=P6^6;
sbit KEY4=P6^7;
sbit KEY5=P3^2;
sbit KEY6=P3^3;
sbit KEY7=P3^4;
sbit KEY8=P3^5;

bit startkey2=0;
bit closekey2=0;
typedef unsigned char u8;
typedef unsigned int u16;

extern LCD_Init1();
extern LCD_Display_Chars1(u8 x,u8 y,u8 *dat);
extern char motor;
extern char count;
unsigned char lie2=0;
unsigned char hang2=0;

u8 key3[]="000000";
u8 keynum2=0;

extern void Delay100ms();	
void key2()
{
	char a=0;
	u8 lednum2;
	
//P2=0x0F;
	KEY1=1;
	KEY2=1;
	KEY3=1;
	KEY4=1;
	KEY5=0;
	KEY6=0;
	KEY7=0;
	KEY8=0;	
	if (KEY1!=1||KEY2!=1||KEY3!=1||KEY4!=1)
	{
//	delay(1000);
		if(KEY1!=1||KEY2!=1||KEY3!=1||KEY4!=1)
		{
			if(KEY1!=1)
			{lie2=1;};
		  if(KEY2!=1)
			{lie2=2;};
			if(KEY3!=1)
			{lie2=3;};
			if(KEY4!=1)
			{lie2=4;};
		}
	KEY1=0;
	KEY2=0;
	KEY3=0;
	KEY4=0;
  KEY5=1;
	KEY6=1;
	KEY7=1;
	KEY8=1;	
	if (KEY5!=1||KEY6!=1||KEY7!=1||KEY8!=1)
	{
	// delay(1000);
		if(KEY5!=1||KEY6!=1||KEY7!=1||KEY8!=1)
		{
			
			if(KEY5!=1)
			{hang2=1;};
		  if(KEY6!=1)
			{hang2=2;};
			if(KEY7!=1)
			{hang2=3;};
			if(KEY8!=1)
			{hang2=4;};
				
		
	   	lednum2=(lie2-1)*4+hang2;
			if(lednum2==13)  //*����������
			{
				for(keynum2=0;keynum2<6;keynum2++)
				{
				key3[keynum2]='0';
				}
				keynum2=0;
				startkey2=1;
			
			
				
			}
			else
			{

			key3[keynum2]=lednum2+'0';
    //  LCD_Display_Chars1(4,1,key3);
		  keynum2++;
			if(keynum2>5)
			{keynum2=0;}
		}
		}
		while((a<50)&&(KEY5!=1||KEY6!=1||KEY7!=1||KEY8!=1))
		{
				Delay100ms();
			a++;
			
			
				
		}}}}
		//Ŀǰ���԰汾������324521
	void keystart2()
	{
	if((key3[0]==('3'))&&(key3[1]==('2'))&&(key3[2]==('5'))&&(key3[3]==('6'))&&(key3[4]==('2'))&&(key3[5]==('1')))
	  {
		LCD_Display_Chars1(3,1,"���    ");
			motor=1;
			count++;
			for(keynum2=0;keynum2<6;keynum2++)
				{
				key3[keynum2]='0';
				}
				keynum2=0;
			closekey2=1;
		}
		else
		{
			LCD_Display_Chars1(3,1,"��������");
		};
	}

