#include <STC8A.h>
#include <intrins.h>
sbit KEY1=P1^4;
sbit KEY2=P4^4;
sbit KEY3=P1^5;
sbit KEY4=P1^6;
sbit KEY5=P1^7;
sbit KEY6=P5^4;
sbit KEY7=P5^5;
sbit KEY8=P4^0;

bit startkey=0;
bit closekey=0;
typedef unsigned char u8;
typedef unsigned int u16;

extern LCD_Init2();
extern LCD_Display_Chars2(u8 x,u8 y,u8 *dat);
extern char motor;
extern char count;
unsigned char lie=0;
unsigned char hang=0;
extern i;
u8 key[]="000000";
u8 keynum=0;

void Delay100ms()		//@5.5296MHz
{
	unsigned char i, j, k;

	i = 3;
	j = 207;
	k = 28;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}


void key1()
{
	char a=0;
	u8 lednum;
	
//P2=0x0F;
	KEY1=1;
	KEY2=1;
	KEY3=1;
	KEY4=1;
	KEY5=0;
	KEY6=0;
	KEY7=0;
	KEY8=0;	
	if (KEY1!=1||KEY2!=1||KEY3!=1||KEY4!=1)
	{
//	delay(1000);
		if(KEY1!=1||KEY2!=1||KEY3!=1||KEY4!=1)
		{
			if(KEY1!=1)
			{lie=1;};
		  if(KEY2!=1)
			{lie=2;};
			if(KEY3!=1)
			{lie=3;};
			if(KEY4!=1)
			{lie=4;};
		}
	KEY1=0;
	KEY2=0;
	KEY3=0;
	KEY4=0;
  KEY5=1;
	KEY6=1;
	KEY7=1;
	KEY8=1;	
	if (KEY5!=1||KEY6!=1||KEY7!=1||KEY8!=1)
	{
	// delay(1000);
		if(KEY5!=1||KEY6!=1||KEY7!=1||KEY8!=1)
		{
			
			if(KEY5!=1)
			{hang=1;};
		  if(KEY6!=1)
			{hang=2;};
			if(KEY7!=1)
			{hang=3;};
			if(KEY8!=1)
			{hang=4;};
				
		
	   	lednum=(lie-1)*4+hang;
			if(lednum==13)  //*����������
			{
				for(keynum=0;keynum<6;keynum++)
				{
				key[keynum]='0';
				}
				keynum=0;
				startkey=1;
			
			//  LCD_Display_Chars1(1,1,key);
				
			}
			else
			{

			key[keynum]=lednum+'0';
      LCD_Display_Chars2(4,1,key);
		  keynum++;
			if(keynum>5)
			{keynum=0;}
		}
		}
		while((a<50)&&(KEY5!=1||KEY6!=1||KEY7!=1||KEY8!=1))
		{
				Delay100ms();
			a++;
			
			
				
		}}}}
		//Ŀǰ���԰汾������324521
	void keystart()
	{
	if((key[0]==('3'))&&(key[1]==('2'))&&(key[2]==('5'))&&(key[3]==('6'))&&(key[4]==('2'))&&(key[5]==('1')))
	  {
		LCD_Display_Chars2(3,1,"�������");
			motor=1;
			count++;
			for(keynum=0;keynum<6;keynum++)
				{
				key[keynum]='0';
				}
				keynum=0;
			closekey=1;
		}
		else
		{
			LCD_Display_Chars2(3,1,"��������");
		};
	}
		
		





//void main()
//{LCD_Init1();

//	while(1)
//	{
//		LCD_Display_Chars1(2,1,"����");
//		key1();
//		//if(key=="123444")
//    if((key[0]==('3'))&&(key[1]==('2'))&&(key[2]==('5'))&&(key[3]==('6'))&&(key[4]==('2'))&&(key[5]==('1')))
//	  {
//		LCD_Display_Chars1(3,1,"�������");
//		}
//		else
//		{
//			LCD_Display_Chars1(3,1,"�������");
//		};
//			
//		
//	}
//}
