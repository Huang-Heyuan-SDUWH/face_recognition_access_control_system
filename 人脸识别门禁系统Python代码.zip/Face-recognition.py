## 将所有需识别的照片放入文件夹

## 远距离识别，但速度较慢   https://blog.csdn.net/SAME999ABC/article/details/82955670

import face_recognition
import cv2
import numpy as np
import datetime
import time
import os
from PIL import Image, ImageDraw, ImageFont

import serial

video_capture = cv2.VideoCapture(0)    # 参数是1，表示打开笔记本的外置摄像头/参数是0 打开内置摄像头

#####################################动态变量命名########################################
# 遍历文件夹中的每一个图片
listName = []
images = os.listdir("known_people")
names = locals()
known_face_encodings = []
known_face_names = []

def GetImageName(dir):
    # 事先对文件夹中所有已知人脸进行编码并存储
    # 获取所有.jpg文件名称，但不带后缀
    for imageName in os.listdir(dir):
        if os.path.splitext(imageName)[1] == '.jpg':
            imageName = os.path.splitext(imageName)[0]
            listName.append(imageName)
            known_face_names.append(imageName)

            for image in images:
                names[str(imageName) + '_image'] = face_recognition.load_image_file("known_people/" + image)
                names[str(imageName) + '_face_encoding'] = face_recognition.face_encodings(names[str(imageName) + '_image'])[0]
                known_face_encodings.append(names[str(imageName) + '_face_encoding'])

GetImageName("known_people")
#print(listName)
#############################################################################################



###########################################人脸识别##########################################
# Initialize some variables
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True
recname = []
rectime = []
datearray = []


Time = datetime.datetime.now().time()


# 一直循环获取摄像头截图并识别和标注
while True:
    # Grab a single frame of video   获取一帧画面
    ret, frame = video_capture.read()

    small_frame = cv2.resize(frame, (0, 0), fx=2, fy=2)    #将画面放大两倍

    # Convert the image from BGR color (which 2OpenCV uses) to RGB color (which face_recognition uses)
    rgb_small_frame = small_frame[:, :, ::-1]

    if process_this_frame:
        # Find all the faces and face encodings in the current frame of video
        # 获取画面中的所有人脸位置及人脸特征码
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        face_names = []
        # 对获取的每个人脸进行识别比对



        for face_encoding in face_encodings:
            # See if the face is a match for the known face(s)
            # 对其中一个人脸的比对结果（可能比对中人脸库中多个人脸）
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.45)
            name = "Unknown"

            # # If a match was found in known_face_encodings, just use the first one.
            # 默认只认为是比对中的第一个人脸.
            if True in matches:
                first_match_index = matches.index(True)
                name = known_face_names[first_match_index]





################################防重复标记################################
                # 判别人脸间隔2分钟消失在镜头前再次进入才做记录
                inside = False

                if inside == False:
                    if name not in recname:
                        recname.append(name)     # 对新出现（或2分钟再次出现）的人脸加入列表记录在案
                        rectime.append(time.time()+28800)   #记录出现时间，加28800是因为转换时间相差28800
                        #print(recname, rectime)
                        inside = True
                        datearray.append(datetime.datetime.utcfromtimestamp(time.time()+28800).strftime("%Y-%m-%d %H:%M:%S"))    #将时间转换成这种显示格式
                        print('recname, datearray:', recname, datearray)
                        fasong=serial.Serial("COM5",9600,timeout=0.5)
                        a=fasong.write(b"1")
                        fasong.close()
                        print("识别成功")
                    else:
                        for i, val in list(enumerate(recname))[::-1]:      # 倒序遍历数组
                            if val == name:
                                if (time.time()+28800) - rectime[i] > 10:    # 如果出现时间距上次出现时间相差2分钟，则记录在内（>60是时间差大于60s的意思）
                                    recname.append(name)
                                    rectime.append(time.time()+28800)
                                    #print(recname, rectime)
                                    inside = True
                                    datearray.append(datetime.datetime.utcfromtimestamp(time.time()+28800).strftime("%Y-%m-%d %H:%M:%S"))
                                    print('recname, datearray:', recname, datearray)
                                    fasong = serial.Serial("COM5", 9600, timeout=0.5)
                                    a = fasong.write(b"1")
                                    fasong.close()
                                    print("识别成功")
                                else:      # 如果出现时间距上次出现时间相差小于2分钟，则不重复记录
                                    inside = True
                                break
##################################################################



            # Or instead, use the known face with the smallest distance to the new face
            # 如果未比对成功，进行最小距离判别
            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]

            else:
                fasong = serial.Serial("COM5", 9600, timeout=0.5)
                a = fasong.write(b"2")
                fasong.close()
                print("识别失败")
            face_names.append(name)


    process_this_frame = not process_this_frame



    # Loop through each face in this frame of video
    # 画出方框
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        top = top / 2
        right = right / 2
        bottom = bottom / 2
        left = left / 2

        # Draw a box around the face
        # 画矩形用于框出人脸
        cv2.rectangle(frame, (round(left), round(top)), (round(right), round(bottom)), (0, 0, 255), 2)
        # https://blog.csdn.net/San_Junipero/article/details/79914773
        # Draw a label with a name below the face
        # 画矩形用于显示识别比对人脸信息
        cv2.rectangle(frame, (round(left), round(bottom) - 35), (round(right), round(bottom)), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_DUPLEX
        # OpenCV原生函数putText是不支持中文字体，所以这里无法写入中文

        # def paint_chinese_opencv(im, chinese, pos, color):
        #     img_PIL = Image.fromarray(cv2.cvtColor(im, cv2.COLOR_BGR2RGB))
        #     font =ImageFont.truetype('NotoSansCJK-Bold.ttc', 25)
        #     fillColor = color  # (255,0,0)
        #     position = pos  # (100,100)
        #     if not isinstance(chinese, str):
        #         chinese = chinese.decode('utf-8')
        #     draw = ImageDraw.Draw(img_PIL)
        #     draw.text(position, chinese, font=font, fill=fillColor)
        #
        #     img = cv2.cvtColor(np.asarray(img_PIL), cv2.COLOR_RGB2BGR)
        #     return img
        # paint_chinese_opencv(frame, "中文", (100,100), (255,255,255))
        # 添加中文
        cv2.putText(frame, name, (round(left) + 6, round(bottom) - 6), font, 1.0, (255, 255, 255), 1)
        #print(name, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))



##################################计算每天打卡的学生人数################################
    # 今天最小时间（今天0点）
    #today_minTime01 = datetime.datetime.combine(datetime.datetime.now(), datetime.time.min).strftime('%H:%M:%S')
    # 今天最大时间（24点）
    today_minTime02 = datetime.datetime.combine(datetime.datetime.now(), datetime.time.max).strftime('%H:%M:%S')
    # 当天23：59：59后开始计算学习时长
    if str(datetime.datetime.now().time()) > today_minTime02:     # 返回当前时间的时分秒（18:40:24.946237）
        num_student = []
        for element in recname:
            if element not in num_student:
                num_student.append(element)
        fg = True
        if fg == True:
            print('今日打卡学生名单:', num_student)
            print('今日打卡学生人数: ', len(num_student))

#########################################################################################



##################################计算每天打卡学生的学习时长#############################
        name_time = list(zip(recname, rectime))   #压缩——返回[(recname1, rectime1), (recname2, rectime2),...,]
        for s in num_student:       # 遍历每个打卡的学生
            names[str(s) + '_name_time'] = []
            for n, t in name_time:
                if s == n:
                    i = name_time.index((n, t))
                    names[str(s) + '_name_time'].append(name_time[i])
                    names[str(s) + '_name'] = list(zip(*(names[str(s) + '_name_time'])))[0]   #解压——返回[(recname1, rectime1)]中的第一个元素recname1；若出现多次则为[recname1, recname2,...]
                    names[str(s) + '_time'] = list(zip(*(names[str(s) + '_name_time'])))[1]   #解压——返回[(recname1, rectime1)]中的第二个元素rectime1；若出现多次则为[rectime1, rectime2,...]

            # print(len(names[str(s) + '_name']))
            # print(names[str(s) + '_name'])
            # print(names[str(s) + '_time'])

            if (len(names[str(s) + '_name']) % 2) == 0:      #表示每次既有签到也有签退
                names[str(s) + '_odd'] = sum(names[str(s) + '_time'][::2])     #计算奇数位置时间和，表示签到时间
                names[str(s) + '_even'] = sum(names[str(s) + '_time'][1::2])   #计算偶数位置时间和，表示签退时间
                names[str(s) + '_study_time'] = names[str(s) + '_even'] - names[str(s) + '_odd']     #签退-签到，表示总的学习时长
                # 将秒数转化为具体时长
                m, se = divmod(names[str(s) + '_study_time'], 60)
                h, m = divmod(m, 60)
                print(s, '的学习时长为',"%d时%02d分%02d秒" % (h, m, se))
            else:      #表示少一次签退
                print(s + '的学习时长不确定')

            # 第二天0点将昨天数据清空，用来记录今天信息
            names[str(s) + '_name_time'] = []
            names[str(s) + '_name'] = []
            names[str(s) + '_time'] = []
            names[str(s) + '_odd'] = []
            names[str(s) + '_even'] = []
            names[str(s) + '_study_time'] = []

        recname = []
        rectime = []
        num_student = []
        name_time = []
        datearray = []

        continue
#############################################################################################


    # Display the resulting image
    cv2.imshow('Video', frame)

    # Hit 'q' on the keyboard to quit!
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release handle to the webcam
video_capture.release()
cv2.destroyAllWindows()
